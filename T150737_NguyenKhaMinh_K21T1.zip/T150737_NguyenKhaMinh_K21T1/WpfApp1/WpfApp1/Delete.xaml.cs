﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for Delete.xaml
    /// </summary>
    public partial class Delete : Window
    {
        public delegate void transCoffe(int[] ID, int Total); // truyen du lieu
        public event transCoffe TransEventCoffe;
        int[] DeleteCoffe = new int[200];
        int TotalCoffe = 0;

        public delegate void transCake(int[] ID, int Total);
        public event transCake TransEventCake;
        int[] DeleteCake = new int[200];
        int TotalCake = 0;

        public delegate void transMilk(int[] ID, int Total);
        public event transMilk TransEventMilk;
        int[] DeleteMilk = new int[200];
        int TotalMilk = 0;

        public delegate void transOrthes(int[] ID, int Total);
        public event transOrthes TransEventOrthes;
        int[] DeleteOrthers = new int[200];
        int TotalOrther = 0;


        bool CoffeTag = false;
        bool CakeTag = false;
        bool OrtherTag = false;
        bool MilkTeaTag = false;
        public Delete()
        {
            InitializeComponent();

        }
        bool delete = false;
        List<string> tagAllList = new List<string>();
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //load source vao comboboxs
            tagAllList.Add("Coffe");
            tagAllList.Add("MilkTea");
            tagAllList.Add("Cake");
            tagAllList.Add("Orther");
            cobo_Menu.ItemsSource = tagAllList.ToList();// dung de load name cua db len thoi
        }

        private void btn_Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void cobo_Menu_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {


            CoffeManagerEntities dbMeo = new CoffeManagerEntities();
            if (cobo_Menu.SelectedItem.ToString() == "MilkTea")
            {
                var itemsMilkTea = from product in dbMeo.MilkTeas select new { product.id, product.Title, product.Price };
                dtgrid_Src.ItemsSource = itemsMilkTea.ToList();
                MilkTeaTag = true;
                CoffeTag = false;
                CakeTag = false;
                OrtherTag = false;
            }
            else if (cobo_Menu.SelectedItem.ToString() == "Coffe")
            {
                var itemsCoffe = from product in dbMeo.Coffes select new { product.id, product.Title, product.Price };
                dtgrid_Src.ItemsSource = itemsCoffe.ToList();
                MilkTeaTag = false;
                CoffeTag = true;
                CakeTag = false;
                OrtherTag = false;

            }
            else if (cobo_Menu.SelectedItem.ToString() == "Orther")
            {
                var itemsOrther = from product in dbMeo.Orthers select new { product.id, product.Title, product.Price };
                dtgrid_Src.ItemsSource = itemsOrther.ToList();
                MilkTeaTag = false;
                CoffeTag = false;
                CakeTag = false;
                OrtherTag = true;

            }
            else if (cobo_Menu.SelectedItem.ToString() == "Cake")
            {
                var itemsCake = from product in dbMeo.Cakes select new { product.id, product.Title, product.Price };
                dtgrid_Src.ItemsSource = itemsCake.ToList();
                MilkTeaTag = false;
                CoffeTag = false;
                CakeTag = true;
                OrtherTag = false;
            }

            if (delete == true)//set gia tri cho button
            { 
                cobo_Menu.IsHitTestVisible = false;
               // MessageBox.Show("Bạn chỉ được delete trong 1 thẻ tag..." + "\n" + "Muốn tiếp tục hãy return...!", "Warning...!");
            }
        }

        private void btn_Delete_Click(object sender, RoutedEventArgs e)
        {
            delteMeo();
        }
        int number = 0;
        public void delteMeo()// ham delete
        {
            delete = true;
            int countDelCoffe = 0;
            int countDelMilk = 0;
            int countDelCake = 0;
            int countDelOrthers = 0;
            if (CoffeTag == false && MilkTeaTag == false && OrtherTag == false && CakeTag == false)
            {
                MessageBox.Show("Please Choose items in Combobox", "Warning...!");
            }
            else
            {
                CoffeManagerEntities dbMeo = new CoffeManagerEntities();
                if (CoffeTag == true)
                {
                    try
                    {
                        number = int.Parse(ChooseMeo.Text);
                        Coffe meo = dbMeo.Coffes.Single(st => st.id == number);
                        dbMeo.Coffes.Remove(meo);
                        dbMeo.SaveChanges();
                        DeleteCoffe[countDelCoffe] = number;
                        countDelCoffe++;
                    }
                    catch
                    {

                    }
                }
                else if (MilkTeaTag == true)
                {
                    try
                    {
                        number = int.Parse(ChooseMeo.Text);
                        MilkTea meo = dbMeo.MilkTeas.Single(st => st.id == number);
                        dbMeo.MilkTeas.Remove(meo);
                        dbMeo.SaveChanges();
                        DeleteMilk[countDelMilk] = number;
                        countDelMilk++;
                    }
                    catch
                    {

                    }
                }
                else if (OrtherTag == true)
                {
                    try
                    {
                        number = int.Parse(ChooseMeo.Text);
                        Orther meo = dbMeo.Orthers.Single(st => st.id == number);
                        dbMeo.Orthers.Remove(meo);
                        dbMeo.SaveChanges();
                        DeleteOrthers[countDelOrthers] = number;
                        countDelOrthers++;
                    }
                    catch
                    {

                    }
                }
                else if (CakeTag == true)
                {
                    try
                    {
                        number = int.Parse(ChooseMeo.Text);
                        Cake meo = dbMeo.Cakes.Single(st => st.id == number);
                        dbMeo.Cakes.Remove(meo);
                        dbMeo.SaveChanges();
                        DeleteCake[countDelCake] = number;
                        countDelCake++;
                    }
                    catch
                    {

                    }
                }
                cobo_Menu_SelectionChanged(null, null);
            }

            TotalCake = countDelCake;
            TotalCoffe = countDelCoffe;
            TotalMilk = countDelMilk;
            TotalOrther = countDelOrthers;
        }
        int meo;//location luc click
        TextBlock ChooseMeo;
        private void dtgrid_Src_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                meo = dtgrid_Src.SelectedIndex;//giong nhu e.index vay. Dung de set gia tri luc click cell
                ChooseMeo = dtgrid_Src.Columns[0].GetCellContent(dtgrid_Src.Items[meo]) as TextBlock;// lay gia tri tai cell click

            }
            catch
            {

            }
        }

        private void btn_Ok_Click(object sender, RoutedEventArgs e)
        {

            TransEventCoffe(DeleteCoffe, TotalCoffe);
            TransEventMilk(DeleteMilk, TotalMilk);
            TransEventCake(DeleteCake, TotalCake);
            TransEventOrthes(DeleteOrthers, TotalOrther);

            this.Close();
        }

        private void cobo_Menu_MouseMove(object sender, MouseEventArgs e)
        {
            if (delete == true)
            {
                MessageBox.Show("Bạn chỉ được delete trong 1 thẻ tag..." + "\n" + "Muốn tiếp tục hãy return...!", "Warning...!");
            }
        }
    }
}
