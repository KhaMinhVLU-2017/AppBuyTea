﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Windows;
//using System.Windows.Controls;
//using System.Windows.Data;
//using System.Windows.Documents;
//using System.Windows.Input;
//using System.Windows.Media;
//using System.Windows.Media.Imaging;
//using System.Windows.Navigation;
//using System.Windows.Shapes;

//namespace WpfApp1
//{
//    / <summary>
//    / Interaction logic for BillPage1.xaml
//    / </summary>
//    public partial class BillPage1 : Page
//    {
//        /*
//        *  coffe
//        */
//        public MyLabelSpecialMeo[] meoLabelCoffe = new MyLabelSpecialMeo[300];
//        public MyLabelSpecialMeo[] meoLabelCoffeNumber = new MyLabelSpecialMeo[300];
//        public MyLabelSpecialMeo[] meoLabelCoffePrice = new MyLabelSpecialMeo[300];
//        public MyLabelSpecialMeo[] meoLabelCoffeTotalPrice = new MyLabelSpecialMeo[300];
//        /*
//         * Cake
//         */
//        public MyLabelSpecialMeo[] meoLabelCake = new MyLabelSpecialMeo[300];
//        public MyLabelSpecialMeo[] meoLabelCakeNumber = new MyLabelSpecialMeo[300];
//        public MyLabelSpecialMeo[] meoLabelCakePrice = new MyLabelSpecialMeo[300];
//        public MyLabelSpecialMeo[] meoLabelCakeTotalPrice = new MyLabelSpecialMeo[300];
//        /*
//         * Orther 
//         */
//        public MyLabelSpecialMeo[] meoLabelOrther = new MyLabelSpecialMeo[300];
//        public MyLabelSpecialMeo[] meoLabelOrtherNumber = new MyLabelSpecialMeo[300];
//        public MyLabelSpecialMeo[] meoLabelOrtherPrice = new MyLabelSpecialMeo[300];
//        public MyLabelSpecialMeo[] meoSpecialOrtherTotalPrice = new MyLabelSpecialMeo[300];
//        /*
//         * Milk
//         */
//        public MyLabelSpecialMeo[] meoLabelMilkTea = new MyLabelSpecialMeo[300];
//        public MyLabelSpecialMeo[] meoLabelMilkTeaNumber = new MyLabelSpecialMeo[300];
//        public MyLabelSpecialMeo[] meoLabelMilkTeaPrice = new MyLabelSpecialMeo[300];
//        public MyLabelSpecialMeo[] meoLabelMilkTeaTotalPrice = new MyLabelSpecialMeo[300];
//        /*
//         * totalArr 
//         */
//        public int MaxcountCoffe = 0;
//        public int MaxcountMilk = 0;
//        public int MaxcountCake = 0;
//        public int MaxcountOrther = 0;
//        public BillPage1()
//        {
//            InitializeComponent();// chua truyen du lieu ddc dcm :((

//        }

//        private void Button_Click(object sender, RoutedEventArgs e)
//        {
//            int withd = 30;
//            int leftTitle = (int)-grid_Main.Width + withd * 2;
//            int top = (int)-300;
//            int right = 0;
//            int buttom = 0;
//            int leftNumber = (int)-grid_Main.Width / 2 + withd * 2;
//            int leftPrice = withd * 2;
//            int leftTotalPrice = (int)grid_Main.Width / 2 + withd;
//            int countRow = 0;
//            int rong = 50;
//            if (MaxcountCake == 0 && MaxcountCoffe == 0 && MaxcountMilk == 0 && MaxcountOrther == 0)
//            {
//                MessageBox.Show("Please Click items For Pay bill");
//            }
//            else
//            {
//                if (MaxcountCoffe != 0)
//                {
//                    for (int i = 0; i < MaxcountCoffe; i++)
//                    {
//                        meoLabelCoffe[i].Margin = new Thickness(leftTitle, top + countRow * withd, right, buttom);// Title label
//                        meoLabelCoffe[i].Width = rong;
//                        meoLabelCoffe[i].Height = withd;
//                        meoLabelCoffe[i].Foreground = Brushes.White;
//                        grid_Main.Children.Add(meoLabelCoffe[i]);

//                        meoLabelCoffeNumber[i].Margin = new Thickness(leftNumber, top + countRow * withd, right, buttom);// Number label
//                        meoLabelCoffeNumber[i].Width = rong;
//                        meoLabelCoffeNumber[i].Height = withd;
//                        meoLabelCoffeNumber[i].Foreground = Brushes.White;
//                        grid_Main.Children.Add(meoLabelCoffeNumber[i]);

//                        meoLabelCoffePrice[i].Margin = new Thickness(leftPrice, top + countRow * withd, right, buttom);// Price
//                        meoLabelCoffePrice[i].Width = rong;
//                        meoLabelCoffePrice[i].Height = withd;
//                        meoLabelCoffePrice[i].Foreground = Brushes.White;
//                        grid_Main.Children.Add(meoLabelCoffePrice[i]);


//                        meoLabelCoffeTotalPrice[i].Margin = new Thickness(leftTotalPrice, top + countRow * withd, right, buttom);// Total Price
//                        meoLabelCoffeTotalPrice[i].Width = rong;
//                        meoLabelCoffeTotalPrice[i].Height = withd;
//                        meoLabelCoffeTotalPrice[i].Foreground = Brushes.White;
//                        grid_Main.Children.Add(meoLabelCoffeTotalPrice[i]);
//                        countRow++;
//                    }
//                }
//                if (MaxcountCake != 0)
//                {
//                    for (int i = 0; i < MaxcountCake; i++)
//                    {
//                        meoLabelCake[i].Margin = new Thickness(leftTitle, top + countRow * withd, right, buttom);// Title label
//                        meoLabelCake[i].Width = rong;
//                        meoLabelCake[i].Height = withd;
//                        meoLabelCake[i].Foreground = Brushes.White;
//                        grid_Main.Children.Add(meoLabelCake[i]);

//                        meoLabelCakeNumber[i].Margin = new Thickness(leftNumber, top + countRow * withd, right, buttom);// Number label
//                        meoLabelCakeNumber[i].Width = rong;
//                        meoLabelCakeNumber[i].Height = withd;
//                        meoLabelCakeNumber[i].Foreground = Brushes.White;
//                        grid_Main.Children.Add(meoLabelCakeNumber[i]);

//                        meoLabelCakePrice[i].Margin = new Thickness(leftPrice, top + countRow * withd, right, buttom);// Price
//                        meoLabelCakePrice[i].Width = rong;
//                        meoLabelCakePrice[i].Height = withd;
//                        meoLabelCakePrice[i].Foreground = Brushes.White;
//                        grid_Main.Children.Add(meoLabelCakePrice[i]);


//                        meoLabelCakeTotalPrice[i].Margin = new Thickness(leftTotalPrice, top + countRow * withd, right, buttom);// Total Price
//                        meoLabelCakeTotalPrice[i].Width = rong;
//                        meoLabelCakeTotalPrice[i].Height = withd;
//                        meoLabelCakeTotalPrice[i].Foreground = Brushes.White;
//                        grid_Main.Children.Add(meoLabelCakeTotalPrice[i]);
//                        countRow++;
//                    }
//                }
//                if (MaxcountMilk != 0)
//                {
//                    for (int i = 0; i < MaxcountMilk; i++)
//                    {
//                        meoLabelMilkTea[i].Margin = new Thickness(leftTitle, top + countRow * withd, right, buttom);// Title label
//                        meoLabelMilkTea[i].Width = rong;
//                        meoLabelMilkTea[i].Height = withd;
//                        meoLabelMilkTea[i].Foreground = Brushes.White;
//                        grid_Main.Children.Add(meoLabelMilkTea[i]);

//                        meoLabelMilkTeaNumber[i].Margin = new Thickness(leftNumber, top + countRow * withd, right, buttom);// Number label
//                        meoLabelMilkTeaNumber[i].Width = rong;
//                        meoLabelMilkTeaNumber[i].Height = withd;
//                        meoLabelMilkTeaNumber[i].Foreground = Brushes.White;
//                        grid_Main.Children.Add(meoLabelMilkTeaNumber[i]);

//                        meoLabelMilkTeaPrice[i].Margin = new Thickness(leftPrice, top + countRow * withd, right, buttom);// Price
//                        meoLabelMilkTeaPrice[i].Width = rong;
//                        meoLabelMilkTeaPrice[i].Height = withd;
//                        meoLabelMilkTeaPrice[i].Foreground = Brushes.White;
//                        grid_Main.Children.Add(meoLabelMilkTeaPrice[i]);


//                        meoLabelMilkTeaTotalPrice[i].Margin = new Thickness(leftTotalPrice, top + countRow * withd, right, buttom);// Total Price
//                        meoLabelMilkTeaTotalPrice[i].Width = rong;
//                        meoLabelMilkTeaTotalPrice[i].Height = withd;
//                        meoLabelMilkTeaTotalPrice[i].Foreground = Brushes.White;
//                        grid_Main.Children.Add(meoLabelMilkTeaTotalPrice[i]);
//                        countRow++;
//                    }
//                }
//                if (MaxcountOrther != 0)
//                {
//                    for (int i = 0; i < MaxcountOrther; i++)
//                    {
//                        meoLabelOrther[i].Margin = new Thickness(leftTitle, top + countRow * withd, right, buttom);// Title label
//                        meoLabelOrther[i].Width = rong;
//                        meoLabelOrther[i].Height = withd;
//                        meoLabelOrther[i].Foreground = Brushes.White;
//                        grid_Main.Children.Add(meoLabelOrther[i]);

//                        meoLabelOrtherNumber[i].Margin = new Thickness(leftNumber, top + countRow * withd, right, buttom);// Number label
//                        meoLabelOrtherNumber[i].Width = rong;
//                        meoLabelOrtherNumber[i].Height = withd;
//                        meoLabelOrtherNumber[i].Foreground = Brushes.White;
//                        grid_Main.Children.Add(meoLabelOrtherNumber[i]);

//                        meoLabelOrtherPrice[i].Margin = new Thickness(leftPrice, top + countRow * withd, right, buttom);// Price
//                        meoLabelOrtherPrice[i].Width = rong;
//                        meoLabelOrtherPrice[i].Height = withd;
//                        meoLabelOrtherPrice[i].Foreground = Brushes.White;
//                        grid_Main.Children.Add(meoLabelOrtherPrice[i]);


//                        meoSpecialOrtherTotalPrice[i].Margin = new Thickness(leftTotalPrice, top + countRow * withd, right, buttom);// Total Price
//                        meoSpecialOrtherTotalPrice[i].Width = rong;
//                        meoSpecialOrtherTotalPrice[i].Height = withd;
//                        meoSpecialOrtherTotalPrice[i].Foreground = Brushes.White;
//                        grid_Main.Children.Add(meoSpecialOrtherTotalPrice[i]);
//                        countRow++;
//                    }
//                }
//            }
//        }

//        private void btn_Oki_Click(object sender, RoutedEventArgs e)
//        {

//            MainWindow main = new MainWindow();
//            main.Show();

//            this.Content = new MainWindow();
//            //this.NavigationService.Navigate(meo);
//        }
//    }

//    public class MyLabelSpecialMeo : Label// dung truyen bill   
//    {
//        private int ID;
//        private string title;
//        private int number;
//        private int price;
//        private int totalPrice;

//        public string Title { get => title; set => title = value; }
//        public int Number { get => number; set => number = value; }
//        public int Price { get => price; set => price = value; }
//        public int TotalPrice { get => totalPrice; set => totalPrice = value; }
//        public int ID1 { get => ID; set => ID = value; }
//    }
//}
