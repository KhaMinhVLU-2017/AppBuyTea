﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Resources;
using System.Windows.Shapes;


namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MenuAdd.xaml
    /// </summary>
    public partial class MenuAdd : Window
    {
        public delegate void transmission(int Price, string PathSourcImage, string Title);
        public event transmission TransmissionEvent;
        bool ChooseImgaesTag = false;
        public MenuAdd()
        {
            InitializeComponent();
            this.gridview_ImgaesAdd.Visibility = Visibility.Hidden;
            ChooseImgaesTag = false;
        }
        
        private void btn_Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        int n = 0;
        private void btn_Apply_Click(object sender, RoutedEventArgs e)
        {
            if (txt_Title.Text!="" && txt_Price.Text != "" && ChooseImgaesTag==true )
            {
                if (int.TryParse(txt_Price.Text, out n))
                {
                    MainWindow meoMain = new MainWindow();
                    TransmissionEvent(int.Parse(txt_Price.Text), PathCurrent, txt_Title.Text); // truyen du lieu vao event de truyen sang form 1
                    MessageBox.Show(String.Format("Title: {0} " + "\n" + "Price: {1}" + "\n" + "Complete", txt_Title.Text, txt_Price.Text), "Notification");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Please Input Number","Warning...!");
                }
            }
            else 
            {
                MessageBox.Show("Please input");
            }
        }
        private void btn_Add_Imgaes(object sender, RoutedEventArgs e)// Button + de add Images vao khung chinh
        {
            ChooseImgaesTag = true;
            MenuChooseImages();
            this.gridview_ImgaesAdd.Visibility = Visibility.Visible;
        }

        public void MenuChooseImages()//Menu Choose Thuc don
        {
            int WidthGrid = (int)gridview_ImgaesAdd.Width;
            int HeightGrid = (int)gridview_ImgaesAdd.Height;
            int Top = HeightGrid / 2;
            int x = -WidthGrid / 2 - 30;
            int y = -Top - 50;
            MyButtonMeo[] btn_Imgaes = new MyButtonMeo[9];

            Image[] img = new Image[9];
            for (int i = 0; i < 9; i++)
            {
                btn_Imgaes[i] = new MyButtonMeo();
                BitmapImage btm = new BitmapImage();// set bit map de co Source
                btn_Imgaes[i].ID1 = i;

                var brushImages = new ImageBrush();
                string pathMeo = String.Format("..//..//ImgaesCoffe//{0}.jpg", i + 1);
                brushImages.ImageSource = new BitmapImage(new Uri(pathMeo, UriKind.RelativeOrAbsolute));
                btn_Imgaes[i].SourceImages1 = pathMeo;
                btn_Imgaes[i].Background = brushImages;
                btn_Imgaes[i].Margin = new Thickness(x, y, 10, 10);
                btn_Imgaes[i].Width = 60;
                btn_Imgaes[i].Height = 60;
                gridview_ImgaesAdd.Children.Add(btn_Imgaes[i]);
                btn_Imgaes[i].Click += new RoutedEventHandler(Clickbtn_Images); // tao sukien cho nhung button
                x = x + 150;
                if (x >= 283)
                {
                    x = -WidthGrid / 2 - 30;
                    y = y + 200;
                }

            }
        }
        string PathCurrent = "";
        private void Clickbtn_Images(object sender, RoutedEventArgs e)//get Source Images Add Menu
        {
            MyButtonMeo getSourcImages = sender as MyButtonMeo;// tao mot doi tuong con cua nhung cai button tren
            PathCurrent = getSourcImages.SourceImages1;//getPath
            var brushMeo = new ImageBrush();// tao brush de set Images Bien' hoa 
            brushMeo.ImageSource = new BitmapImage(new Uri(PathCurrent, UriKind.RelativeOrAbsolute));//get duong dan images vao tu bitmap
            btn_Add.Background = brushMeo;
            gridview_ImgaesAdd.Visibility = Visibility.Hidden;
        }

     
    }
}
