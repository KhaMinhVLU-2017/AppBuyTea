﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public bool btn_CoffeTag = false; // xac dinh de biet add vao Menu nao
        public bool btn_MilkTeaTag = false;
        public bool btn_CakeTag = false;
        public bool btn_OrtherTag = false;
        /*
         * * Danh Cho coffe
         */
        MyButtonMeo[] btn_AutoAddCoffe = new MyButtonMeo[100000];//button hien thi in Menu Coffe
        MyLabelMeo[] lbl_MeoTitleCoffe = new MyLabelMeo[100000];//Label in Menu Coffe
        MyLabelMeo[] lbl_CountLabelTouchCoffe = new MyLabelMeo[100000];// Label in menu Coffe
        /*
         * * Danh Cho MilkTea
         */
        MyButtonMeo[] btn_AutoAddMilk = new MyButtonMeo[100000];//button hien thi in Menu MilkTea
        MyLabelMeo[] lbl_MeoTitleMilk = new MyLabelMeo[100000];//Label in Menu Milk
        MyLabelMeo[] lbl_CountLabelTouchMilk = new MyLabelMeo[100000];// Label in menu MilkTea
        /*
         * * Danh cho Cake
         */
        MyButtonMeo[] btn_AutoAddCake = new MyButtonMeo[100000];//button hien thi in Menu Cake
        MyLabelMeo[] lbl_MeoTitleCake = new MyLabelMeo[100000];//Label in Menu Cake
        MyLabelMeo[] lbl_CountLabelTouchCake = new MyLabelMeo[100000];// Label in menu Cake
        /*
         * * Danh Cho Orther
         */
        MyButtonMeo[] btn_AutoAddOrther = new MyButtonMeo[100000];//button hien thi in Menu Cake
        MyLabelMeo[] lbl_MeoTitleOrther = new MyLabelMeo[100000];//Label in Menu Cake
        MyLabelMeo[] lbl_CountLabelTouchOrther = new MyLabelMeo[100000];// Label in menu Cake


        int countBtn = 0;
        int sizeWith = 60;
        int sizeHeight = 60;



   
        public MainWindow()
        {
        
            InitializeComponent();
            src_Milk.Visibility = Visibility.Hidden;
            src_Cake.Visibility = Visibility.Hidden;
            src_Orther.Visibility = Visibility.Hidden;
            src_Coffe.Visibility = Visibility.Hidden;
            txt_Number.IsEnabled = false;
            txt_TotalMoneyScreen.IsEnabled = false;
        }

        private void btn_add_Click(object sender, RoutedEventArgs e)
        {
        
            if (btn_MilkTeaTag == false && btn_CoffeTag == false && btn_CakeTag == false && btn_OrtherTag == false)
            {
                MessageBox.Show("Please Choose 1 Tag");
            }
            else
            {
                MenuAdd meoAdd = new MenuAdd(); // hien thi screeen chon tra sua
                meoAdd.TransmissionEvent += EventTransForm1;
                meoAdd.ShowDialog();
                Window_Loaded(null, null);
              
            }

        }


        public void MenuAutoAddbutton(MyButtonMeo[] btn, Grid MeoTag, MyLabelMeo[] lbl_Title, MyLabelMeo[] lbl_Touch, System.Linq.IQueryable<WpfApp1.Coffe> table) //add button vao grid
        {
            /*
             *  sua lai cho no load db len
             */
            int x = 0;
            int y = 60;
            int countGrid = 0;
            foreach (var id in table)
            {
                btn[id.id] = new MyButtonMeo();// Button Hien thi thuc don tra sua cac Items
                btn[id.id].SL1 = 0; // so luogn sp
                btn[id.id].ID1 = id.id; // id san pham
                btn[id.id].Name1 = id.Title; // ten san pham

                //btn[id.id].Content = btn[id.id].Name1;
                btn[id.id].Margin = new Thickness(x - 30, 0, grid_Coffe.Width / 2 - sizeWith * countGrid, grid_Coffe.Height - y); // location
                btn[id.id].Width = sizeWith;
                btn[id.id].Height = sizeHeight;
                btn[id.id].Price1 = (int)id.Price; // gia tien san pham
                var brushMeo = new ImageBrush();//tao mot brush de set background button
                brushMeo.ImageSource = new BitmapImage(new Uri(id.SourceImages, UriKind.RelativeOrAbsolute));// lay source ve


                btn[id.id].Background = brushMeo;// set images cho button
                MeoTag.Children.Add(btn[id.id]); // add san pham vao

                lbl_Title[id.id] = new MyLabelMeo();// Label hien thi Ten cua san pham  Items
                lbl_Title[id.id].ID1 = id.id; // id Label
                lbl_Title[id.id].Ten1 = id.Title; // ten Label hien thi cho button
                lbl_Title[id.id].Content = lbl_Title[id.id].Ten1; // hien thi ten label len man hinh
                lbl_Title[id.id].Margin = new Thickness(x - 30, 0, grid_Coffe.Width / 2 - sizeWith * countGrid, grid_Coffe.Height - y - 80);//location
                lbl_Title[id.id].Width = 60;
                lbl_Title[id.id].Height = 30;
                lbl_Title[id.id].FontSize = 10; // size label hien thi duoi button
                lbl_Title[id.id].Foreground = Brushes.White;
                MeoTag.Children.Add(lbl_Title[id.id]);// add label vao man hinh

                lbl_Touch[id.id] = new MyLabelMeo();// button hien thi so luong san pham
                lbl_Touch[id.id].Margin = new Thickness(x, -5, grid_Coffe.Width / 2 - sizeWith * countGrid, grid_Coffe.Height - y + 40);
                lbl_Touch[id.id].Width = 50;
                lbl_Touch[id.id].Height = 30;
                lbl_Touch[id.id].FontSize = 15;
                MeoTag.Children.Add(lbl_Touch[id.id]); // add label so luong san pham vao man hinh
                btn[id.id].Click += new RoutedEventHandler(ActionClickCoffe);// su kien cho label

                x = x + sizeWith + 10;
                //countBtn++;
                countGrid++; // tinh so lan xuat hien cua san pham de dua ra khoang cach giua cac san pham
                if (x >= grid_Coffe.Width) // xet dk cho no xuong dong
                {
                    x = 0;
                    y = y + sizeHeight * 3;
                    countGrid = 0;
                }
            }

        }
        public void MenuAutoAddbutton(MyButtonMeo[] btn, Grid MeoTag, MyLabelMeo[] lbl_Title, MyLabelMeo[] lbl_Touch, System.Linq.IQueryable<WpfApp1.MilkTea> TableMeo) //add button vao grid
        {
            /*
             *  sua lai cho no load db len
             */
            int x = 0;
            int y = 60;
            int countGrid = 0;
            foreach (var id in TableMeo)
            {
                btn[id.id] = new MyButtonMeo();// Button Hien thi thuc don tra sua cac Items
                btn[id.id].SL1 = 0; // so luogn sp
                btn[id.id].ID1 = id.id; // id san pham
                btn[id.id].Name1 = id.Title; // ten san pham

                btn[id.id].Margin = new Thickness(x - 30, 0, grid_Coffe.Width / 2 - sizeWith * countGrid, grid_Coffe.Height - y); // location
                btn[id.id].Width = sizeWith;
                btn[id.id].Height = sizeHeight;
                btn[id.id].Price1 = (int)id.Price; // gia tien san pham
                var brushMeo = new ImageBrush();//tao mot brush de set background button
                brushMeo.ImageSource = new BitmapImage(new Uri(id.SourceImages, UriKind.RelativeOrAbsolute));// lay source ve


                btn[id.id].Background = brushMeo;// set images cho button
                MeoTag.Children.Add(btn[id.id]); // add san pham vao

                lbl_Title[id.id] = new MyLabelMeo();// Label hien thi Ten cua san pham  Items
                lbl_Title[id.id].ID1 = id.id; // id Label
                lbl_Title[id.id].Ten1 = id.Title; // ten Label hien thi cho button
                lbl_Title[id.id].Content = lbl_Title[id.id].Ten1; // hien thi ten label len man hinh
                lbl_Title[id.id].Margin = new Thickness(x - 30, 0, grid_Coffe.Width / 2 - sizeWith * countGrid, grid_Coffe.Height - y - 80);//location
                lbl_Title[id.id].Width = 60;
                lbl_Title[id.id].Height = 30;
                lbl_Title[id.id].FontSize = 10; // size label hien thi duoi button
                MeoTag.Children.Add(lbl_Title[id.id]);// add label vao man hinh

                lbl_Touch[id.id] = new MyLabelMeo();// button hien thi so luong san pham
                lbl_Touch[id.id].Margin = new Thickness(x, -5, grid_Coffe.Width / 2 - sizeWith * countGrid, grid_Coffe.Height - y + 40);
                lbl_Touch[id.id].Width = 50;
                lbl_Touch[id.id].Height = 30;
                lbl_Touch[id.id].FontSize = 15;
                lbl_Title[id.id].Foreground = Brushes.White;
                MeoTag.Children.Add(lbl_Touch[id.id]); // add label so luong san pham vao man hinh
                btn[id.id].Click += new RoutedEventHandler(ActionClickMilk);// su kien cho label

                x = x + sizeWith + 10;

                countGrid++; // tinh so lan xuat hien cua san pham de dua ra khoang cach giua cac san pham
                if (x >= grid_Coffe.Width) // xet dk cho no xuong dong
                {
                    x = 0;
                    y = y + sizeHeight * 3;
                    countGrid = 0;
                }
            }
        }
        public void MenuAutoAddbutton(MyButtonMeo[] btn, Grid MeoTag, MyLabelMeo[] lbl_Title, MyLabelMeo[] lbl_Touch, System.Linq.IQueryable<WpfApp1.Orther> TableMeo) //add button vao grid
        {
            /*
             *  sua lai cho no load db len
             */
            int x = 0;
            int y = 60;
            int countGrid = 0;
            foreach (var id in TableMeo)
            {
                btn[id.id] = new MyButtonMeo();// Button Hien thi thuc don tra sua cac Items
                btn[id.id].SL1 = 0; // so luogn sp
                btn[id.id].ID1 = id.id; // id san pham
                btn[id.id].Name1 = id.Title; // ten san pham

                btn[id.id].Margin = new Thickness(x - 30, 0, grid_Coffe.Width / 2 - sizeWith * countGrid, grid_Coffe.Height - y); // location
                btn[id.id].Width = sizeWith;
                btn[id.id].Height = sizeHeight;
                btn[id.id].Price1 = (int)id.Price; // gia tien san pham
                var brushMeo = new ImageBrush();//tao mot brush de set background button
                brushMeo.ImageSource = new BitmapImage(new Uri(id.SourceImgaes, UriKind.RelativeOrAbsolute));// lay source ve


                btn[id.id].Background = brushMeo;// set images cho button
                MeoTag.Children.Add(btn[id.id]); // add san pham vao

                lbl_Title[id.id] = new MyLabelMeo();// Label hien thi Ten cua san pham  Items
                lbl_Title[id.id].ID1 = id.id; // id Label
                lbl_Title[id.id].Ten1 = id.Title; // ten Label hien thi cho button
                lbl_Title[id.id].Content = lbl_Title[id.id].Ten1; // hien thi ten label len man hinh
                lbl_Title[id.id].Margin = new Thickness(x - 30, 0, grid_Coffe.Width / 2 - sizeWith * countGrid, grid_Coffe.Height - y - 80);//location
                lbl_Title[id.id].Width = 60;
                lbl_Title[id.id].Height = 30;
                lbl_Title[id.id].FontSize = 10; // size label hien thi duoi button
                MeoTag.Children.Add(lbl_Title[id.id]);// add label vao man hinh

                lbl_Touch[id.id] = new MyLabelMeo();// button hien thi so luong san pham
                lbl_Touch[id.id].Margin = new Thickness(x, -5, grid_Coffe.Width / 2 - sizeWith * countGrid, grid_Coffe.Height - y + 40);
                lbl_Touch[id.id].Width = 50;
                lbl_Touch[id.id].Height = 30;
                lbl_Touch[id.id].FontSize = 15;
                lbl_Title[id.id].Foreground = Brushes.White;
                MeoTag.Children.Add(lbl_Touch[id.id]); // add label so luong san pham vao man hinh
                btn[id.id].Click += new RoutedEventHandler(ActionClickOrther);// su kien cho label

                x = x + sizeWith + 10;

                countGrid++; // tinh so lan xuat hien cua san pham de dua ra khoang cach giua cac san pham
                if (x >= grid_Coffe.Width) // xet dk cho no xuong dong
                {
                    x = 0;
                    y = y + sizeHeight * 3;
                    countGrid = 0;
                }
            }
        }
        public void MenuAutoAddbutton(MyButtonMeo[] btn, Grid MeoTag, MyLabelMeo[] lbl_Title, MyLabelMeo[] lbl_Touch, System.Linq.IQueryable<WpfApp1.Cake> TableMeo) //add button vao grid
        {
            /*
             *  sua lai cho no load db len
             */
            int x = 0;
            int y = 60;
            int countGrid = 0;
            foreach (var id in TableMeo)
            {
                btn[id.id] = new MyButtonMeo();// Button Hien thi thuc don tra sua cac Items
                btn[id.id].SL1 = 0; // so luogn sp
                btn[id.id].ID1 = id.id; // id san pham
                btn[id.id].Name1 = id.Title; // ten san pham
                btn[id.id].Margin = new Thickness(x - 30, 0, grid_Coffe.Width / 2 - sizeWith * countGrid, grid_Coffe.Height - y); // location
                btn[id.id].Width = sizeWith;
                btn[id.id].Height = sizeHeight;
                btn[id.id].Price1 = (int)id.Price; // gia tien san pham
                var brushMeo = new ImageBrush();//tao mot brush de set background button
                brushMeo.ImageSource = new BitmapImage(new Uri(id.SourceImgaes, UriKind.RelativeOrAbsolute));// lay source ve


                btn[id.id].Background = brushMeo;// set images cho button
                MeoTag.Children.Add(btn[id.id]); // add san pham vao

                lbl_Title[id.id] = new MyLabelMeo();// Label hien thi Ten cua san pham  Items
                lbl_Title[id.id].ID1 = id.id; // id Label
                lbl_Title[id.id].Ten1 = id.Title; // ten Label hien thi cho button
                lbl_Title[id.id].Content = lbl_Title[id.id].Ten1; // hien thi ten label len man hinh
                lbl_Title[id.id].Margin = new Thickness(x - 30, 0, grid_Coffe.Width / 2 - sizeWith * countGrid, grid_Coffe.Height - y - 80);//location
                lbl_Title[id.id].Width = 60;
                lbl_Title[id.id].Height = 30;
                lbl_Title[id.id].FontSize = 10; // size label hien thi duoi button
                                                // lbl_Title[id.id].Background = Brushes.White;
                MeoTag.Children.Add(lbl_Title[id.id]);// add label vao man hinh

                lbl_Touch[id.id] = new MyLabelMeo();// button hien thi so luong san pham
                lbl_Touch[id.id].Margin = new Thickness(x, -5, grid_Coffe.Width / 2 - sizeWith * countGrid, grid_Coffe.Height - y + 40);
                lbl_Touch[id.id].Width = 50;
                lbl_Touch[id.id].Height = 30;
                lbl_Touch[id.id].FontSize = 15;
                lbl_Title[id.id].Foreground = Brushes.White;
                MeoTag.Children.Add(lbl_Touch[id.id]); // add label so luong san pham vao man hinh
                btn[id.id].Click += new RoutedEventHandler(ActionClickCake);// su kien cho label

                x = x + sizeWith + 10;

                countGrid++; // tinh so lan xuat hien cua san pham de dua ra khoang cach giua cac san pham
                if (x >= grid_Coffe.Width) // xet dk cho no xuong dong
                {
                    x = 0;
                    y = y + sizeHeight * 3;
                    countGrid = 0;
                }
            }
        }





        int countCLick = 1;// dem so lan nhan vao san pham
        int TotalMoneyInt = 0;// tong so tien Phai tra cho Bill
        private void ActionClickCoffe(object sender, RoutedEventArgs e)// action khu click cua moi button trong menu
        {
            MyButtonMeo btn = sender as MyButtonMeo;
            btn.SL1 += 1;
            txt_Number.Text = countCLick + ""; // hien thi so luogn san pham da chon
            lblTouchMeoScreenCoffe(btn.ID1, btn.SL1);// hien thi so lan click tren items mau do
            TotalMoneyInt += btn.Price1;//tong so tien khi click cac item
            txt_TotalMoneyScreen.Text = TotalMoneyInt.ToString();// hien thi tong so tien phai tra
            countCLick++;
        }
        public void lblTouchMeoScreenCoffe(int id, int Click) // hien thi Label tren button tinh so lan click
        {
            lbl_CountLabelTouchCoffe[id].SL1 = Click;
            lbl_CountLabelTouchCoffe[id].Foreground = Brushes.Red;
            lbl_CountLabelTouchCoffe[id].Content = lbl_CountLabelTouchCoffe[id].SL1;
        }
        private void ActionClickMilk(object sender, RoutedEventArgs e)// action khu click cua moi button trong menu
        {
            MyButtonMeo btn = sender as MyButtonMeo;
            btn.SL1 += 1;
            txt_Number.Text = countCLick + ""; // hien thi so luong san pham da chon
            lblTouchMeoScreenMilk(btn.ID1, btn.SL1);// hien thi so lan chon items mau do
            TotalMoneyInt += btn.Price1;// tong so tien phai tra cho bill
            txt_TotalMoneyScreen.Text = TotalMoneyInt + ""; // hien tong so tien phai tra cho bill
            countCLick++;
        }
        public void lblTouchMeoScreenMilk(int id, int Click) // hien thi Label tren button tinh so lan click
        {
            lbl_CountLabelTouchMilk[id].SL1 = Click;
            lbl_CountLabelTouchMilk[id].Foreground = Brushes.Red;
            lbl_CountLabelTouchMilk[id].Content = lbl_CountLabelTouchMilk[id].SL1;
        }
        private void ActionClickCake(object sender, RoutedEventArgs e)// action khu click cua moi button trong menu
        {
            MyButtonMeo btn = sender as MyButtonMeo;
            btn.SL1 += 1;
            txt_Number.Text = countCLick + ""; // hien thi so luong san pham da chon
            lblTouchMeoScreenCake(btn.ID1, btn.SL1);// hien thi so lan chon items mau do
            TotalMoneyInt += btn.Price1;// tong so tien phai tra cho bill
            txt_TotalMoneyScreen.Text = TotalMoneyInt + ""; // hien tong so tien phai tra cho bill
            countCLick++;
        }
        public void lblTouchMeoScreenCake(int id, int Click) // hien thi Label tren button tinh so lan click
        {
            lbl_CountLabelTouchCake[id].SL1 = Click;
            lbl_CountLabelTouchCake[id].Foreground = Brushes.Red;
            lbl_CountLabelTouchCake[id].Content = lbl_CountLabelTouchCake[id].SL1;
        }
        private void ActionClickOrther(object sender, RoutedEventArgs e)// action khu click cua moi button trong menu
        {
            MyButtonMeo btn = sender as MyButtonMeo;
            btn.SL1 += 1;
            txt_Number.Text = countCLick + ""; // hien thi so luong san pham da chon
            lblTouchMeoScreenOrther(btn.ID1, btn.SL1);// hien thi so lan chon items mau do
            TotalMoneyInt += btn.Price1;// tong so tien phai tra cho bill
            txt_TotalMoneyScreen.Text = TotalMoneyInt + ""; // hien tong so tien phai tra cho bill
            countCLick++;
        }
        public void lblTouchMeoScreenOrther(int id, int Click) // hien thi Label tren button tinh so lan click
        {
            lbl_CountLabelTouchOrther[id].SL1 = Click;
            lbl_CountLabelTouchOrther[id].Foreground = Brushes.Red;
            lbl_CountLabelTouchOrther[id].Content = lbl_CountLabelTouchOrther[id].SL1;
        }



        private void EventTransForm1(int Price, string Path, string Title)
        {
            CoffeManagerEntities dbMeo = new CoffeManagerEntities();
            Coffe TableCoffe = new Coffe();
            Cake TableCake = new Cake();
            Orther TableOrther = new Orther();
            MilkTea TableMilk = new MilkTea();
            //int idCoffe = TableCoffe.id+1;
            //int idMilk = TableMilk.id+1;
            //int idCake = TableCake.id+1;
            //int idOrther = TableOrther.id+1;
            if (btn_CoffeTag == true) // dk de add vao moi tag
            {
                //TableCoffe.id = idCoffe;
                TableCoffe.Price = Price;
                TableCoffe.SourceImages = Path;
                TableCoffe.Title = Title;
                dbMeo.Coffes.Add(TableCoffe);
                dbMeo.SaveChanges();
                //idCoffe++;
            }
            else if (btn_MilkTeaTag == true)
            {
                //TableMilk.id = idMilk;
                TableMilk.Price = Price;
                TableMilk.SourceImages = Path;
                TableMilk.Title = Title;
                dbMeo.MilkTeas.Add(TableMilk);
                dbMeo.SaveChanges();
                // idMilk++;
            }
            else if (btn_CakeTag == true)
            {
                //TableCake.id = idCake;
                TableCake.Price = Price;
                TableCake.SourceImgaes = Path;
                TableCake.Title = Title;
                dbMeo.Cakes.Add(TableCake);
                dbMeo.SaveChanges();
                //idCake++;
            }
            else if (btn_OrtherTag == true)
            {
                //TableOrther.id = idOrther;
                TableOrther.Price = Price;
                TableOrther.SourceImgaes = Path;
                TableOrther.Title = Title;
                dbMeo.Orthers.Add(TableOrther);
                dbMeo.SaveChanges();
                // idOrther++;
            }


        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            CoffeManagerEntities bdMeo = new CoffeManagerEntities();
            var itemCoffe = from tableCoffe in bdMeo.Coffes select tableCoffe;
            var itemMileTea = from tableMilk in bdMeo.MilkTeas select tableMilk;
            var itemCake = from tableCake in bdMeo.Cakes select tableCake;
            var itemOrther = from tableOrther in bdMeo.Orthers select tableOrther;
            MenuAutoAddbutton(btn_AutoAddCoffe, grid_Coffe, lbl_MeoTitleCoffe, lbl_CountLabelTouchCoffe, itemCoffe);// load items
            MenuAutoAddbutton(btn_AutoAddMilk, grid_MilkTea, lbl_MeoTitleMilk, lbl_CountLabelTouchMilk, itemMileTea);
            MenuAutoAddbutton(btn_AutoAddCake, grid_Cake, lbl_MeoTitleCake, lbl_CountLabelTouchCake, itemCake);
            MenuAutoAddbutton(btn_AutoAddOrther, grid_Orther, lbl_MeoTitleOrther, lbl_CountLabelTouchOrther, itemOrther);
        }
        private void btn_Coffe_Click(object sender, RoutedEventArgs e)
        {
            src_Coffe.Visibility = Visibility.Visible;
            src_Cake.Visibility = Visibility.Hidden;
            src_Orther.Visibility = Visibility.Hidden;
            src_Milk.Visibility = Visibility.Hidden;
            btn_MilkTeaTag = false;
            btn_CoffeTag = true;
            btn_OrtherTag = false;
            btn_CakeTag = false;
         

        }
        private void btn_MilkTea_Click(object sender, RoutedEventArgs e)
        {
            src_Milk.Visibility = Visibility.Visible;
            src_Cake.Visibility = Visibility.Hidden;
            src_Orther.Visibility = Visibility.Hidden;
            src_Coffe.Visibility = Visibility.Hidden;
            btn_MilkTeaTag = true;
            btn_CoffeTag = false;
            btn_OrtherTag = false;
            btn_CakeTag = false;

        }

        private void btn_Cake_Click(object sender, RoutedEventArgs e)
        {
            src_Milk.Visibility = Visibility.Hidden;
            src_Cake.Visibility = Visibility.Visible;
            src_Orther.Visibility = Visibility.Hidden;
            src_Coffe.Visibility = Visibility.Hidden;
            btn_MilkTeaTag = false;
            btn_CoffeTag = false;
            btn_OrtherTag = false;
            btn_CakeTag = true;

        }

        private void btn_Orther_Click(object sender, RoutedEventArgs e)
        {
            src_Milk.Visibility = Visibility.Hidden;
            src_Cake.Visibility = Visibility.Hidden;
            src_Orther.Visibility = Visibility.Visible;
            src_Coffe.Visibility = Visibility.Hidden;
            btn_MilkTeaTag = false;
            btn_CoffeTag = false;
            btn_OrtherTag = true;
            btn_CakeTag = false;

        }

        private void Window_Closed(object sender, EventArgs e)
        {
            this.Close();
        }
        private void tb_btn_Clear_Click(object sender, RoutedEventArgs e)// clear toan bo items da chon
        {
            Window_Loaded(null, null); // load lai
            txt_Number.Clear(); // clear text box
            txt_TotalMoneyScreen.Clear();// clear text box
            countCLick = 1; // set Gia tri so luong lai  =1
            TotalMoneyInt = 0;// clear total =0
        }

        private void tb_btn_Delete_Click(object sender, RoutedEventArgs e)
        {
            Delete meoDelete = new Delete(); // hien thi man hinh delete
            meoDelete.TransEventCoffe += EventCoffedel;
            meoDelete.TransEventCake += EventCakedel;
            meoDelete.TransEventMilk += EventMilkdel;
            meoDelete.TransEventOrthes += EventOrtherdel;
            meoDelete.ShowDialog();
            Window_Loaded(null, null);


        }

        private void EventCoffedel(int[] Coffe, int TotalCoffe)
        {
            if (TotalCoffe != 0)
            {
                for (int i = 0; i < TotalCoffe; i++)//remove itemse
                {
                    grid_Coffe.Children.Remove(btn_AutoAddCoffe[Coffe[i]]);
                    grid_Coffe.Children.Remove(lbl_MeoTitleCoffe[Coffe[i]]);
                    grid_Coffe.Children.Remove(lbl_CountLabelTouchCoffe[Coffe[i]]);
                    grid_Coffe.Children.Clear();
                }
            }
            Window_Loaded(null, null);

        }
        private void EventCakedel(int[] Cake, int TotalCake)
        {
            if (TotalCake != 0)
            {
                for (int i = 0; i < TotalCake; i++)
                {
                    grid_Cake.Children.Remove(btn_AutoAddCake[Cake[i]]);
                    grid_Cake.Children.Remove(lbl_MeoTitleCake[Cake[i]]);
                    grid_Cake.Children.Remove(lbl_CountLabelTouchCake[Cake[i]]);
                    grid_Cake.Children.Clear();

                }
            }
            Window_Loaded(null, null);

        }
        private void EventMilkdel(int[] Milk, int TotalMilk)
        {
            if (TotalMilk != 0)
            {
                for (int i = 0; i < TotalMilk; i++)
                {
                    grid_MilkTea.Children.Remove(btn_AutoAddMilk[Milk[i]]);
                    grid_MilkTea.Children.Remove(lbl_MeoTitleMilk[Milk[i]]);
                    grid_MilkTea.Children.Remove(lbl_CountLabelTouchMilk[Milk[i]]);
                    grid_MilkTea.Children.Clear();
                }
                Window_Loaded(null, null);
            }


        }
        private void EventOrtherdel(int[] Orthes, int TotalOrther)
        {

            if (TotalOrther != 0)
            {
                for (int i = 0; i < TotalOrther; i++)
                {
                    grid_Orther.Children.Remove(btn_AutoAddOrther[Orthes[i]]);
                    grid_Orther.Children.Remove(lbl_MeoTitleOrther[Orthes[i]]);
                    grid_Orther.Children.Remove(lbl_CountLabelTouchOrther[Orthes[i]]);
                    grid_Orther.Children.Clear();
                }
            }
            Window_Loaded(null, null);

        }

        private void btn_Apply_Click(object sender, RoutedEventArgs e)
        {

            CoffeManagerEntities bdMeo = new CoffeManagerEntities();
            BillTest meo = new BillTest();
            Bill MainBill = new Bill();
            var itemCoffe = from tableCoffe in bdMeo.Coffes select tableCoffe;
            var itemMileTea = from tableMilk in bdMeo.MilkTeas select tableMilk;
            var itemCake = from tableCake in bdMeo.Cakes select tableCake;
            var itemOrther = from tableOrther in bdMeo.Orthers select tableOrther;
            MainBill.Time = DateTime.Now;
            bdMeo.Bills.Add(MainBill);
            bdMeo.SaveChanges();
            meo.TotalBillScreen[0] = new MyLabelSpecialMeo();
            int countCoffe = 0;
            int countMilk = 0;
            int countCake = 0;
            int countOrther = 0;
            foreach (var idMeo in itemCoffe)// tinh tong so tien torng billdetal nhap vao db
            {
                try
                {
                    if (btn_AutoAddCoffe[idMeo.id].SL1 != 0)
                    {
                        CoffeManagerEntities dbSecondMeo = new CoffeManagerEntities();
                        Detail_Bill billBoj = new Detail_Bill();
                        meo.meoLabelCoffe[countCoffe] = new MyLabelSpecialMeo();// ten label
                        meo.meoLabelCoffeNumber[countCoffe] = new MyLabelSpecialMeo();// Number
                        meo.meoLabelCoffePrice[countCoffe] = new MyLabelSpecialMeo();//Price label
                        meo.meoLabelCoffeTotalPrice[countCoffe] = new MyLabelSpecialMeo();//totalprice

                        // meo.meoLabelCoffe[countCoffe].ID1 = countCoffe;//truyen du lieu sang page
                        meo.meoLabelCoffe[countCoffe].Title = idMeo.Title;// truyen ten sang page
                        meo.meoLabelCoffe[countCoffe].Content = idMeo.Title;
                        meo.meoLabelCoffeNumber[countCoffe].Content = btn_AutoAddCoffe[idMeo.id].SL1;//truyen number sang page so lan click ak
                        meo.meoLabelCoffePrice[countCoffe].Content = (int)idMeo.Price;// truyen so tien qa
                        meo.meoLabelCoffeTotalPrice[countCoffe].Content = (int)idMeo.Price * btn_AutoAddCoffe[idMeo.id].SL1;//tong tien
                        meo.TotalBillScreen[0].TotalPrice = meo.TotalBillScreen[0].TotalPrice + (int)idMeo.Price * btn_AutoAddCoffe[idMeo.id].SL1;        //tong tien
                        billBoj.id_SP = idMeo.id;
                        billBoj.Title = idMeo.Title;
                        billBoj.Number = btn_AutoAddCoffe[idMeo.id].SL1;//so lan click
                        billBoj.Price = idMeo.Price;
                        billBoj.TotalPrice = billBoj.Number * idMeo.Price;
                        billBoj.id_Bill = MainBill.ID_Bill;
                        dbSecondMeo.Detail_Bill.Add(billBoj);
                        dbSecondMeo.SaveChanges();
                        countCoffe++;
                    }
                }
                catch { }
            }
       
            foreach (var idMeo in itemMileTea)
            {
                try
                {
                    if (btn_AutoAddMilk[idMeo.id].SL1 != 0)
                    {
                        CoffeManagerEntities dbSecondMeo = new CoffeManagerEntities();
                        Detail_Bill billBoj = new Detail_Bill();
                        meo.meoLabelMilkTea[countMilk] = new MyLabelSpecialMeo();// ten label
                        meo.meoLabelMilkTeaNumber[countMilk] = new MyLabelSpecialMeo();// Number
                        meo.meoLabelMilkTeaPrice[countMilk] = new MyLabelSpecialMeo();//Price label
                        meo.meoLabelMilkTeaTotalPrice[countMilk] = new MyLabelSpecialMeo();//totalprice

                        //meo.meoLabelMilkTea[countCoffe].Title = idMeo.Title;// truyen ten sang page
                        meo.meoLabelMilkTea[countMilk].Content = idMeo.Title;
                        meo.meoLabelMilkTeaNumber[countMilk].Content = btn_AutoAddMilk[idMeo.id].SL1;//truyen number sang page so lan click ak
                        meo.meoLabelMilkTeaPrice[countMilk].Content = (int)idMeo.Price;// truyen so tien qa
                        meo.meoLabelMilkTeaTotalPrice[countMilk].Content = (int)idMeo.Price * btn_AutoAddMilk[idMeo.id].SL1;//tong tien
                        meo.TotalBillScreen[0].TotalPrice += (int)idMeo.Price * btn_AutoAddMilk[idMeo.id].SL1;//tong tien screen


                        billBoj.id_SP = idMeo.id;
                        billBoj.Title = idMeo.Title;
                        billBoj.Number = btn_AutoAddMilk[idMeo.id].SL1;//so lan click
                        billBoj.Price = idMeo.Price;
                        billBoj.TotalPrice = billBoj.Number * idMeo.Price;
                        billBoj.id_Bill = MainBill.ID_Bill;
                        dbSecondMeo.Detail_Bill.Add(billBoj);
                        dbSecondMeo.SaveChanges();
                        countMilk++;
                    }
                }
                catch { }
            }// tinh tong so tien torng billdetal nhap vao db
            foreach (var idMeo in itemCake)
            {
                try
                {
                    if (btn_AutoAddCake[idMeo.id].SL1 != 0)
                    {
                        CoffeManagerEntities dbSecondMeo = new CoffeManagerEntities();
                        Detail_Bill billBoj = new Detail_Bill();
                        meo.meoLabelCake[countCake] = new MyLabelSpecialMeo();
                        meo.meoLabelCakeNumber[countCake] = new MyLabelSpecialMeo();// Number
                        meo.meoLabelCakePrice[countCake] = new MyLabelSpecialMeo();//Price label
                        meo.meoLabelCakeTotalPrice[countCake] = new MyLabelSpecialMeo();//totalprice

                        meo.meoLabelCake[countCake].Content = idMeo.Title;
                        meo.meoLabelCakeNumber[countCake].Content = btn_AutoAddCake[idMeo.id].SL1;//truyen number sang page so lan click ak
                        meo.meoLabelCakePrice[countCake].Content = (int)idMeo.Price;// truyen so tien qa
                        meo.meoLabelCakeTotalPrice[countCake].Content = (int)idMeo.Price * btn_AutoAddCake[idMeo.id].SL1;//tong tien
                        meo.TotalBillScreen[0].TotalPrice += (int)idMeo.Price * btn_AutoAddCake[idMeo.id].SL1;//toen tien screen

                        billBoj.id_SP = idMeo.id;
                        billBoj.Title = idMeo.Title;
                        billBoj.Number = btn_AutoAddCake[idMeo.id].SL1;//so lan click
                        billBoj.Price = idMeo.Price;
                        billBoj.TotalPrice = billBoj.Number * idMeo.Price;
                        billBoj.id_Bill = MainBill.ID_Bill;
                        dbSecondMeo.Detail_Bill.Add(billBoj);
                        dbSecondMeo.SaveChanges();
                        countCake++;
                    }
                }
                catch { }
            }// tinh tong so tien torng billdetal nhap vao db
            foreach (var idMeo in itemOrther)
            {
                try
                {
                    if (btn_AutoAddOrther[idMeo.id].SL1 != 0)
                    {
                        CoffeManagerEntities dbSecondMeo = new CoffeManagerEntities();
                        Detail_Bill billBoj = new Detail_Bill();
                        meo.meoLabelOrther[countOrther] = new MyLabelSpecialMeo();
                        meo.meoLabelOrtherNumber[countOrther] = new MyLabelSpecialMeo();// Number
                        meo.meoLabelOrtherPrice[countOrther] = new MyLabelSpecialMeo();//Price label
                        meo.meoSpecialOrtherTotalPrice[countOrther] = new MyLabelSpecialMeo();//totalprice

                        meo.meoLabelOrther[countOrther].Content = idMeo.Title;
                        meo.meoLabelOrtherNumber[countOrther].Content = btn_AutoAddOrther[idMeo.id].SL1;//truyen number sang page so lan click ak
                        meo.meoLabelOrtherPrice[countOrther].Content = (int)idMeo.Price;// truyen so tien qa
                        meo.meoSpecialOrtherTotalPrice[countOrther].Content = (int)idMeo.Price * btn_AutoAddOrther[idMeo.id].SL1;//tong tien
                        meo.TotalBillScreen[0].TotalPrice += (int)idMeo.Price * btn_AutoAddOrther[idMeo.id].SL1;

                        billBoj.id_SP = idMeo.id;
                        billBoj.Title = idMeo.Title;
                        billBoj.Number = btn_AutoAddOrther[idMeo.id].SL1;//so lan click
                        billBoj.Price = idMeo.Price;
                        billBoj.TotalPrice = billBoj.Number * idMeo.Price;
                        billBoj.id_Bill = MainBill.ID_Bill;
                        dbSecondMeo.Detail_Bill.Add(billBoj);
                        dbSecondMeo.SaveChanges();
                        countOrther++;
                    }
                }
                catch { }
            }// tinh tong so tien torng billdetal nhap vao db

            meo.TotalBillScreen[0].Content = meo.TotalBillScreen[0].TotalPrice;//tong bill truyen qa kia
            meo.MaxcountCoffe = countCoffe;
            meo.MaxcountCake = countCake;
            meo.MaxcountMilk = countMilk;
            meo.MaxcountOrther = countOrther;
            meo.ShowDialog();
            Window_Loaded(null, null);
        }
    }

}
public class MyButtonMeo : Button
{
    private int ID; // solan click
    private int SL;
    private string Name;
    private string SourceImages;
    private int Price;
    public MyButtonMeo() { }
    public string Name1 { get => Name; set => Name = value; }
    public string SourceImages1 { get => SourceImages; set => SourceImages = value; }
    public int Price1 { get => Price; set => Price = value; }
    public int ID1 { get => ID; set => ID = value; }
    public int SL1 { get => SL; set => SL = value; }
}// My button Special 
public class MyLabelMeo : Label
{
    private int ID;
    private int SL;// so lan click
    private string Ten;
    private int Price;
    public MyLabelMeo() { }
    public int ID1 { get => ID; set => ID = value; }
    public string Ten1 { get => Ten; set => Ten = value; }
    public int SL1 { get => SL; set => SL = value; }
    public int Price1 { get => Price; set => Price = value; }
}// my Label Special

